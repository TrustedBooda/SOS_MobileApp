package com.example.ethan.mydocument;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.net.URI;

public class MainActivity extends AppCompatActivity {

    Button selectFile,upload, fetch;
    TextView notification;
    Uri pdfUri; // uri are URLs meant for local storage
    FirebaseStorage storage; //used for uploading files... ex: pdf
    FirebaseDatabase database; // used to store URLs of uploaded files
    ProgressDialog progressDialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

         fetch=findViewById(R.id.fetchFiles);
         fetch.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 startActivity(new Intent(MainActivity.this , MyRecyclerViewActivity.class));
             }
         });
        storage=FirebaseStorage.getInstance(); //returns an object of firebase storage
        database=FirebaseDatabase.getInstance(); //returns an object of firebase database

        selectFile=findViewById(R.id.selectFile);
        upload=findViewById(R.id.upload);
        notification=findViewById(R.id.notification);

        selectFile.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {

                if(ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE)==PackageManager.PERMISSION_GRANTED){
                    selectPDF();

                }
                else
                    ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},9);

            }

        });

            upload.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(pdfUri!=null) {
                        uploadFile(pdfUri); //the user has successfully selected a file
                    }
                    else
                        Toast.makeText(MainActivity.this, "Select a file",Toast.LENGTH_SHORT).show();

                }
            });
    }
    private void uploadFile(Uri pdfUri){

        progressDialog=new ProgressDialog(this);
        progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        progressDialog.setTitle("Uploading File...");
        progressDialog.setProgress(0);
        progressDialog.show();

        final String fileName=System.currentTimeMillis()+".pdf";
       final String fileName1 = System.currentTimeMillis()+"";
        StorageReference storageReference=storage.getReference(); //returns root path

        storageReference.child("Uploads").child(fileName).putFile(pdfUri)
                .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    String url= taskSnapshot.getMetadata().getReference().getDownloadUrl().toString();
                    //store url in realtime database
                        DatabaseReference reference=database.getReference(); //returns path to root

                        reference.child(fileName1).setValue(url).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if(task.isSuccessful()){
                                    Toast.makeText(MainActivity.this, "File Successfully uploaded",Toast.LENGTH_SHORT).show();
                                }
                                else
                                    Toast.makeText(MainActivity.this, "File not Successfully uploaded",Toast.LENGTH_SHORT).show();

                            }
                        });


                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {

                Toast.makeText(MainActivity.this, "File not Successfully uploaded",Toast.LENGTH_SHORT).show();

            }
        }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {

                //track the progress of our upload
                int currentProgress=(int) (100*taskSnapshot.getBytesTransferred()/taskSnapshot.getTotalByteCount());
                    progressDialog.setProgress(currentProgress);
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {

        if(requestCode==9 && grantResults[0]==PackageManager.PERMISSION_GRANTED){
            selectPDF();
        }
        else
            Toast.makeText(MainActivity.this, "Please provide permission", Toast.LENGTH_SHORT).show();
    }

    private void selectPDF() {

        //offer user to select file using file manager
        //using intent

        Intent intent = new Intent();
        intent.setType("application/pdf");
        intent.setAction(Intent.ACTION_GET_CONTENT); //to fetch files
        startActivityForResult(intent, 86);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        //check whether user has selected a file or not (PDF)
        if(requestCode==86 && resultCode==RESULT_OK && data!=null){
            pdfUri=data.getData(); //return uri of selected file
            notification.setText("A file is selected: "+ data.getData().getLastPathSegment());
        }
        else{
            Toast.makeText(MainActivity.this,"Please select a file", Toast.LENGTH_SHORT).show();
        }
    }
}

